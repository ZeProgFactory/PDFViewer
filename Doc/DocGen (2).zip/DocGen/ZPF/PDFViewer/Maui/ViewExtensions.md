
<table style="background-color:#444; width: 100%;">
<tr>
<td align='left' >
<img width="441" height="1">
<div style="font-weight: bold; font-size: 26px;"> 📚 Documentation PDFViewer</div>
</td>
<td align='right' >
<img width="441" height="1">   
<a href="../../../index.md">Index</a>
</td>
</tr>
</table>

---
# `ViewExtensions`

**Namespace** : `ZPF.PDFViewer.Maui`

---


&nbsp;   
&nbsp;<br/>
## Rect `GetBoundingBox` ( VisualElement view ) 

---


