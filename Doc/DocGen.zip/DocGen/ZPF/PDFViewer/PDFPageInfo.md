# `PDFPageInfo`

**Namespace :** `ZPF.PDFViewer`

---

## `Height`

**Résumé :**

Height in cm

---


## `ImageSource`

**Résumé :**



---


## `Scale`

**Résumé :**

Gets or sets the scale factor applied to the element.                           Remarks:                Default value is 1.0.

---


## `Width`

**Résumé :**

Width in cm

---


