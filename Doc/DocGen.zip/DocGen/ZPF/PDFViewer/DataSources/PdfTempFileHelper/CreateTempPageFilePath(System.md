# `CreateTempPageFilePath(System`

**Namespace :** `ZPF.PDFViewer.DataSources.PdfTempFileHelper`

---

## `String)`

**Résumé :**

Creates a unique temporary file path for a page file.

---


