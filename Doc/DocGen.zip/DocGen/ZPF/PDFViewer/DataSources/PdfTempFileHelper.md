# `PdfTempFileHelper`

**Namespace :** `ZPF.PDFViewer.DataSources`

---

## `CreateTempPdfFilePath`

**Résumé :**

Creates a unique temporary file path for a PDF file.

---


