# `PDFInfos`

**Namespace :** `ZPF.PDFViewer`

---

## `IsPasswordProtected`

**Résumé :**

Gets whether the Portable Document Format (PDF) document is password-protected.

---


