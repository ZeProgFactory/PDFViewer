# `String,System`

**Namespace :** `ZPF.PDFViewer.Maui.PDFViewer.LoadPDF(ZPF.PDFViewer.DataSources.IPdfSource,System`

---

## `String)`

**Résumé :**

Load PDF from URL wo rendering it.             The rendering is done when pages (ImageFileName) are requested.

- **param `pdfSource`** : 
- **param `url`** : 
**Retour :**



---


